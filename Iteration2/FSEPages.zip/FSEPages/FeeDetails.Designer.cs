﻿namespace FSEPages
{
    partial class FeeDetails
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            headingLabel = new Label();
            feeTable = new DataGridView();
            SerialNumber = new DataGridViewTextBoxColumn();
            Semester = new DataGridViewTextBoxColumn();
            ID = new DataGridViewTextBoxColumn();
            Amount = new DataGridViewTextBoxColumn();
            DueDate = new DataGridViewTextBoxColumn();
            Status = new DataGridViewCheckBoxColumn();
            generateChallan = new Button();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)feeTable).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // headingLabel
            // 
            headingLabel.AutoSize = true;
            headingLabel.Font = new Font("Nirmala UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            headingLabel.ForeColor = Color.White;
            headingLabel.Location = new Point(204, 9);
            headingLabel.Name = "headingLabel";
            headingLabel.Size = new Size(210, 50);
            headingLabel.TabIndex = 0;
            headingLabel.Text = "Fee Details\r\n";
            headingLabel.Click += label1_Click;
            // 
            // feeTable
            // 
            feeTable.AllowUserToAddRows = false;
            feeTable.AllowUserToDeleteRows = false;
            feeTable.AllowUserToResizeColumns = false;
            feeTable.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.LightGray;
            dataGridViewCellStyle1.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = Color.LightGray;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.ControlText;
            feeTable.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            feeTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            feeTable.BackgroundColor = Color.White;
            feeTable.BorderStyle = BorderStyle.None;
            feeTable.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.DodgerBlue;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            feeTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            feeTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            feeTable.Columns.AddRange(new DataGridViewColumn[] { SerialNumber, Semester, ID, Amount, DueDate, Status });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = Color.White;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            feeTable.DefaultCellStyle = dataGridViewCellStyle3;
            feeTable.EditMode = DataGridViewEditMode.EditProgrammatically;
            feeTable.EnableHeadersVisualStyles = false;
            feeTable.GridColor = Color.LightGray;
            feeTable.Location = new Point(45, 110);
            feeTable.MultiSelect = false;
            feeTable.Name = "feeTable";
            feeTable.ReadOnly = true;
            feeTable.RowHeadersVisible = false;
            feeTable.RowHeadersWidth = 51;
            feeTable.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            feeTable.ShowCellErrors = false;
            feeTable.ShowCellToolTips = false;
            feeTable.ShowEditingIcon = false;
            feeTable.ShowRowErrors = false;
            feeTable.Size = new Size(516, 188);
            feeTable.TabIndex = 1;
            feeTable.CellContentClick += feeTable_CellContentClick;
            // 
            // SerialNumber
            // 
            SerialNumber.HeaderText = "S No";
            SerialNumber.MinimumWidth = 6;
            SerialNumber.Name = "SerialNumber";
            SerialNumber.ReadOnly = true;
            // 
            // Semester
            // 
            Semester.HeaderText = "Semester";
            Semester.MinimumWidth = 6;
            Semester.Name = "Semester";
            Semester.ReadOnly = true;
            // 
            // ID
            // 
            ID.HeaderText = "Challan ID";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.ReadOnly = true;
            // 
            // Amount
            // 
            Amount.HeaderText = "Amount";
            Amount.MinimumWidth = 6;
            Amount.Name = "Amount";
            Amount.ReadOnly = true;
            // 
            // DueDate
            // 
            DueDate.HeaderText = "Due Date";
            DueDate.MinimumWidth = 6;
            DueDate.Name = "DueDate";
            DueDate.ReadOnly = true;
            // 
            // Status
            // 
            Status.HeaderText = "Status";
            Status.MinimumWidth = 6;
            Status.Name = "Status";
            Status.ReadOnly = true;
            // 
            // generateChallan
            // 
            generateChallan.BackColor = Color.DodgerBlue;
            generateChallan.FlatStyle = FlatStyle.Popup;
            generateChallan.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            generateChallan.ForeColor = Color.White;
            generateChallan.Location = new Point(215, 328);
            generateChallan.Name = "generateChallan";
            generateChallan.Size = new Size(145, 29);
            generateChallan.TabIndex = 2;
            generateChallan.Text = "Generate Challan";
            generateChallan.UseVisualStyleBackColor = false;
            generateChallan.Click += generateChallan_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(headingLabel);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(604, 69);
            panel1.TabIndex = 3;
            // 
            // FeeDetails
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(604, 382);
            Controls.Add(panel1);
            Controls.Add(generateChallan);
            Controls.Add(feeTable);
            Name = "FeeDetails";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)feeTable).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label headingLabel;
        private DataGridView feeTable;
        private DataGridViewTextBoxColumn SerialNumber;
        private DataGridViewTextBoxColumn Semester;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Amount;
        private DataGridViewTextBoxColumn DueDate;
        private DataGridViewCheckBoxColumn Status;
        private Button generateChallan;
        private Panel panel1;
    }
}
