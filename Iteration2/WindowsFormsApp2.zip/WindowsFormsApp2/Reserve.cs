﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Reserve : Form
    {
        private HashSet<Button> redButtons = new HashSet<Button>(); 
        private Button selectedSeat = null; 

        public Reserve()
        {
            InitializeComponent();
            this.Load += Reserve_Load;
        }

        private void SetupButtonEvents(Button btn)
        {
            btn.MouseDown += (s, e) =>
            {
                if (btn == selectedSeat) 
                {
                    btn.BackColor = Color.White;
                    selectedSeat = null;
                }
                else if (selectedSeat == null) 
                {
                    btn.BackColor = Color.LightSeaGreen;
                    selectedSeat = btn;
                }
                else
                {
                    MessageBox.Show("You can select only one seat", "Seat Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };

            btn.MouseUp += (s, e) =>
            {
                if (redButtons.Contains(btn))
                {
                    btn.BackColor = Color.Red;
                }
                else if (btn != selectedSeat) 
                {
                    btn.BackColor = Color.White;
                }
            };
        }

        private void RandomizeButtons()
        {
            List<Button> buttons = panel1.Controls.OfType<Button>().ToList();

            if (buttons.Count == 0)
            {
                MessageBox.Show("No buttons found inside panel1!");
                return;
            }

            Random rand = new Random();
            int countToColor = Math.Min(14, buttons.Count);
            var randomButtons = buttons.OrderBy(x => rand.Next()).Take(countToColor).ToList();

            foreach (var btn in randomButtons)
            {
                btn.BackColor = Color.Red;
                redButtons.Add(btn); 
            }
        }

        private void SetupButtons()
        {
            List<Button> buttons = panel1.Controls.OfType<Button>().ToList();

            foreach (var btn in buttons)
            {
                if (!redButtons.Contains(btn)) 
                {
                    btn.BackColor = Color.White;
                }
                SetupButtonEvents(btn); 
            }
        }

        private void Reserve_Load(object sender, EventArgs e)
        {
            RandomizeButtons();
            SetupButtons();
        }

        private void button31_Click(object sender, EventArgs e)
        {

        }

        private void button32_Click(object sender, EventArgs e)
        {
            Home homePage = new Home(); 
            homePage.Show();                    
            this.Hide();
        }

        private void button33_Click(object sender, EventArgs e)
        {
            Routes routesPage = new Routes(); 
            routesPage.Show();               
            this.Hide();
        }

        private void button34_Click(object sender, EventArgs e)
        {
            // add for fees
        }

        private void button35_Click(object sender, EventArgs e)
        {
            // for schedule
        }

        private void button36_Click(object sender, EventArgs e)
        {
            Reserve reservePage = new Reserve();
            reservePage.Show();
            this.Hide();
        }

        private void button37_Click(object sender, EventArgs e)
        {
            // notifications
        }

        private void button38_Click(object sender, EventArgs e)
        {
            Feedback feedbackPage = new Feedback();
            feedbackPage.Show();
            this.Hide();
        }

        private void button39_Click(object sender, EventArgs e)
        {
            Contact contactPage = new Contact();
            contactPage.Show();
            this.Hide();
        }
    }
}
