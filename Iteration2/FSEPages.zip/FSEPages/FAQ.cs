﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FSEPages
{
    public partial class FAQ : Form
    {
        private Dictionary<string, string> faqResponses = new Dictionary<string, string>()
        {
            { "What is the bus arrival time?", "Bus arrival time is at 7:00 AM, 8:30 AM and 10:00 AM." },
            { "What is the bus departure time?", "Bus departure time is at 2:30 PM, 4:00 PM and 5:30 PM." },
            { "What is the bus fee for this semester?", "Visit the fee section for this information." },
            { "What are payment options?", "Payment options include credit card, bank transfer, and cash." },
            { "How can I track bus?", "You can track the bus using the tracking feature." },
            { "How can I apply for bus transportation?", "You can register for transporation through the app." },
            { "Can I change my bus route?", "Yes, you can request a route change through the transportation office." },
            { "Are buses available on weekends?", "No, only available for special cases" },
            { "Are buses available during examinations?", "Yes, buses are available during examinations." },
            { "Who should I contact for bus complaints?", "Contact haider pookie." }
        };
        public FAQ()
        {
            InitializeComponent();
            this.DoubleBuffered = true;

            responseLabel.AutoSize = false;
            responseLabel.TextAlign = ContentAlignment.TopLeft;
            responseLabel.Dock = DockStyle.Fill;
            responseLabel.MaximumSize = new Size(responsePanel.Width - 10, 0);
            responseLabel.ForeColor = Color.White;
            responseLabel.BringToFront();

            transparentPanel.BackColor = Color.FromArgb(120, 0, 128, 128);

            // ✅ FIX: Clear items before adding to avoid duplicates
            faqDropDown.Items.Clear();
            faqDropDown.Items.AddRange(faqResponses.Keys.ToArray());
            faqDropDown.SelectedIndex = 0;
            faqDropDown.FlatStyle = FlatStyle.Flat;
            faqDropDown.DropDownStyle = ComboBoxStyle.DropDownList;
            faqDropDown.TabStop = false;
            AdjustDropDownWidth(faqDropDown);
            faqDropDown.DrawMode = DrawMode.OwnerDrawFixed;
            faqDropDown.DropDownStyle = ComboBoxStyle.DropDownList;

            faqDropDown.DrawItem += (s, e) =>
            {
                if (e.Index < 0) return;

                // Set hover and selection color
                Color backColor;
                Color textColor;

                if ((e.State & DrawItemState.Selected) != 0) // When hovered or selected
                {
                    backColor = Color.DarkCyan; // Custom hover/selection background color
                    textColor = Color.White; // Text color for hover/selection
                }
                else
                {
                    backColor = Color.Black; // Background color for normal state
                    textColor = Color.White; // Text color for normal state
                }

                // Fill background and draw text
                e.Graphics.FillRectangle(new SolidBrush(backColor), e.Bounds);
                e.Graphics.DrawString(faqDropDown.Items[e.Index].ToString(), e.Font, new SolidBrush(textColor), e.Bounds);

                e.DrawFocusRectangle(); // Keep focus rectangle visible
            };


            submitButton.FlatStyle = FlatStyle.Flat;
            submitButton.BackColor = Color.FromArgb(0, 76, 76);
            submitButton.ForeColor = Color.White;
            submitButton.FlatAppearance.BorderSize = 0;
            submitButton.FlatAppearance.MouseOverBackColor = Color.DarkCyan;
            submitButton.FlatAppearance.MouseDownBackColor = Color.LightSeaGreen;
            submitButton.Size = new Size(94, 28);
            submitButton.Cursor = Cursors.Hand;
            submitButton.TextAlign = ContentAlignment.TopCenter;

            // ✅ FIX: Prevent multiple event attachment
            submitButton.Click -= SubmitButton_Click;
            submitButton.Click += SubmitButton_Click;
        }

        private void transparentPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FAQHeading_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            // Fixing the null warning issue
            string selectedQuestion = faqDropDown.SelectedItem?.ToString() ?? string.Empty;

            if (!string.IsNullOrEmpty(selectedQuestion) && faqResponses.ContainsKey(selectedQuestion))
            {
                // Display the corresponding response in the label
                responseLabel.Text = faqResponses[selectedQuestion];
            }
            else
            {
                responseLabel.Text = "Please select a valid question.";
            }
        }

        private void faqDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AdjustDropDownWidth(ComboBox dropDown)
        {
            int maxWidth = 0;
            using (Graphics g = dropDown.CreateGraphics())
            {
                foreach (var item in dropDown.Items)
                {
                    int itemWidth = (int)g.MeasureString(item.ToString(), dropDown.Font).Width;
                    if (itemWidth > maxWidth)
                        maxWidth = itemWidth;
                }
            }

            dropDown.DropDownWidth = maxWidth + 25; // Add some padding
        }
    }
}
