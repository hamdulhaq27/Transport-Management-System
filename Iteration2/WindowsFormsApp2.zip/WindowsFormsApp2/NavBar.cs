﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class NavBar : UserControl
    {
        public NavBar()
        {
            InitializeComponent();
        }

        private void NavBar_Load(object sender, EventArgs e)
        {

        }

        private void button32_Click(object sender, EventArgs e)
        {
            Home homePage = new Home();
            homePage.Show();
            this.ParentForm.Close();
        }

        private void button33_Click_1(object sender, EventArgs e)
        {
            Routes routesPage = new Routes();
            routesPage.Show();
            this.ParentForm.Close();
        }

        private void button34_Click_1(object sender, EventArgs e)
        {
        }

        private void button35_Click_1(object sender, EventArgs e)
        {
        }

        private void button36_Click_1(object sender, EventArgs e)
        {
            Reserve reservePage = new Reserve();
            reservePage.Show();
            this.ParentForm.Close();
        }

        private void button37_Click_1(object sender, EventArgs e)
        {
        }

        private void button38_Click_1(object sender, EventArgs e)
        {
            Feedback feedbackPage = new Feedback();
            feedbackPage.Show();
            this.ParentForm.Close();
        }

        private void button39_Click_1(object sender, EventArgs e)
        {
            Contact contactPage = new Contact();
            contactPage.Show();
            this.ParentForm.Close();
        }


    }
}
