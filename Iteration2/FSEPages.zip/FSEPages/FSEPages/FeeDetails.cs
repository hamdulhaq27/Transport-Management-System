using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace FSEPages
{
    public partial class FeeDetails : Form
    {
        public FeeDetails()
        {
            InitializeComponent();
            CenterLabel();

            feeTable.AutoGenerateColumns = false;
            feeTable.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
            feeTable.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
            feeTable.Columns[2].SortMode = DataGridViewColumnSortMode.NotSortable;
            feeTable.Columns[3].SortMode = DataGridViewColumnSortMode.NotSortable;
            feeTable.Columns[4].SortMode = DataGridViewColumnSortMode.NotSortable;
            feeTable.Columns[5].SortMode = DataGridViewColumnSortMode.NotSortable;


            feeTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            feeTable.ColumnHeadersHeight = 40; // Adjust the value as needed
            feeTable.Rows.Add("1", "Spring 2025", "1040", "53,000", "31 Mar 2025", false);
            feeTable.Rows.Add("2", "Fall 2024", "1030", "49,500", "9 Dec 2024", true);
            feeTable.Rows.Add("3", "Spring 2024", "1020", "47,500", "27 Mar 2024", true);
            feeTable.Rows.Add("4", "Fall 2023", "1010", "45,000", "6 Dec 2023", true);

            StyleButton(); // Apply styling to existing button
        }

        private void CenterLabel()
        {

            // Center the label horizontally and vertically
            headingLabel.Left = (this.ClientSize.Width - headingLabel.Width) / 2;
        }

        private void FeeDetails_Load(object sender, EventArgs e)
        {
            CenterLabel(); // Center label on form load
        }

        private void FeeDetails_Resize(object sender, EventArgs e)
        {
            CenterLabel(); // Keep label centered on resize

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void feeTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void StyleButton()
        {
            Color customSlateBlue = Color.FromArgb(74, 63, 143); // Darker SlateBlue
            generateChallan.BackColor = Color.DodgerBlue;
            generateChallan.ForeColor = Color.White;
            generateChallan.FlatStyle = FlatStyle.Flat;
            generateChallan.FlatAppearance.BorderSize = 0;
            generateChallan.Font = new Font("Nirmala UI", 10, FontStyle.Bold);
            generateChallan.Size = new Size(180, 40); // Bigger size for better look
            generateChallan.Cursor = Cursors.Hand;
            // Draw rounded corners using GraphicsPath
            generateChallan.Paint += (s, e) =>
            {
                using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int radius = 20;
                    path.AddArc(1, 1, radius, radius, 180, 90);
                    path.AddArc(generateChallan.Width - radius - 1, 1, radius, radius, 270, 90);
                    path.AddArc(generateChallan.Width - radius - 1, generateChallan.Height - radius - 1, radius, radius, 0, 90);
                    path.AddArc(1, generateChallan.Height - radius - 1, radius, radius, 90, 90);
                    path.CloseFigure();

                    generateChallan.Region = new Region(path);

                    e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                    // Use ControlPaint for cleaner borders
                    ControlPaint.DrawBorder(e.Graphics, generateChallan.ClientRectangle,
                                            Color.DarkBlue, ButtonBorderStyle.Solid);
                }
            };

            // Hover effect
            generateChallan.MouseEnter += (s, e) =>
            {
                generateChallan.BackColor = Color.MidnightBlue;
            };

            generateChallan.MouseLeave += (s, e) =>
            {
                generateChallan.BackColor = Color.DodgerBlue;
            };

            // Click effect
            generateChallan.MouseDown += (s, e) =>
            {
                generateChallan.BackColor = customSlateBlue;
            };

            generateChallan.MouseUp += (s, e) =>
            {
                generateChallan.BackColor = Color.MidnightBlue; // Reset to hover color
            };
        }

        private void generateChallan_Click(object sender, EventArgs e)
        {
            DataGridViewRow rowToCopy = null;

            foreach (DataGridViewRow row in feeTable.Rows)
            {
                // Assuming Status is the last column (adjust index if needed)
                if (row.Cells[5].Value != null && !(bool)row.Cells[5].Value)
                {
                    rowToCopy = row;
                    break; // Pick the first unpaid row
                }
            }

            if (rowToCopy != null)
            {
                // Create and show the GenerateFee form
                GenerateFee generateFeeForm = new GenerateFee();
                generateFeeForm.CopyDataToLayoutPanel(rowToCopy);
                generateFeeForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("No unpaid fees found.");
            }
        }

    }
}
