﻿namespace FSEPages
{
    partial class GenerateFee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            generateLabel = new Label();
            generateLayoutPanel = new TableLayoutPanel();
            panel10 = new Panel();
            label10 = new Label();
            panel9 = new Panel();
            label9 = new Label();
            panel8 = new Panel();
            label8 = new Label();
            panel7 = new Panel();
            label7 = new Label();
            panel5 = new Panel();
            label5 = new Label();
            panel4 = new Panel();
            label4 = new Label();
            panel3 = new Panel();
            label3 = new Label();
            panel2 = new Panel();
            label2 = new Label();
            textBox1 = new TextBox();
            label11 = new Label();
            label13 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            label14 = new Label();
            printChallan = new Button();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel14 = new Panel();
            panel15 = new Panel();
            label12 = new Label();
            panel16 = new Panel();
            generateLayoutPanel.SuspendLayout();
            panel10.SuspendLayout();
            panel9.SuspendLayout();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel15.SuspendLayout();
            panel16.SuspendLayout();
            SuspendLayout();
            // 
            // generateLabel
            // 
            generateLabel.AutoSize = true;
            generateLabel.Font = new Font("Nirmala UI", 22F, FontStyle.Bold);
            generateLabel.ForeColor = Color.White;
            generateLabel.Location = new Point(178, 10);
            generateLabel.Name = "generateLabel";
            generateLabel.Size = new Size(248, 50);
            generateLabel.TabIndex = 1;
            generateLabel.Text = "Generate Fee";
            generateLabel.TextAlign = ContentAlignment.MiddleCenter;
            generateLabel.Click += generateLabel_Click;
            // 
            // generateLayoutPanel
            // 
            generateLayoutPanel.ColumnCount = 4;
            generateLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            generateLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            generateLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            generateLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            generateLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            generateLayoutPanel.Controls.Add(panel10, 3, 1);
            generateLayoutPanel.Controls.Add(panel9, 2, 1);
            generateLayoutPanel.Controls.Add(panel8, 1, 1);
            generateLayoutPanel.Controls.Add(panel7, 0, 1);
            generateLayoutPanel.Controls.Add(panel5, 3, 0);
            generateLayoutPanel.Controls.Add(panel4, 2, 0);
            generateLayoutPanel.Controls.Add(panel3, 1, 0);
            generateLayoutPanel.Controls.Add(panel2, 0, 0);
            generateLayoutPanel.Location = new Point(9, 86);
            generateLayoutPanel.Name = "generateLayoutPanel";
            generateLayoutPanel.RowCount = 2;
            generateLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            generateLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            generateLayoutPanel.Size = new Size(583, 112);
            generateLayoutPanel.TabIndex = 2;
            // 
            // panel10
            // 
            panel10.BackColor = Color.White;
            panel10.Controls.Add(label10);
            panel10.Dock = DockStyle.Fill;
            panel10.ForeColor = SystemColors.ControlText;
            panel10.Location = new Point(438, 59);
            panel10.Name = "panel10";
            panel10.Size = new Size(142, 50);
            panel10.TabIndex = 9;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(34, 15);
            label10.Name = "label10";
            label10.Size = new Size(58, 20);
            label10.TabIndex = 0;
            label10.Text = "label10";
            // 
            // panel9
            // 
            panel9.BackColor = Color.White;
            panel9.Controls.Add(label9);
            panel9.Dock = DockStyle.Fill;
            panel9.ForeColor = SystemColors.ControlText;
            panel9.Location = new Point(293, 59);
            panel9.Name = "panel9";
            panel9.Size = new Size(139, 50);
            panel9.TabIndex = 8;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(34, 15);
            label9.Name = "label9";
            label9.Size = new Size(50, 20);
            label9.TabIndex = 0;
            label9.Text = "label9";
            // 
            // panel8
            // 
            panel8.BackColor = Color.White;
            panel8.Controls.Add(label8);
            panel8.Dock = DockStyle.Fill;
            panel8.ForeColor = SystemColors.ControlText;
            panel8.Location = new Point(148, 59);
            panel8.Name = "panel8";
            panel8.Size = new Size(139, 50);
            panel8.TabIndex = 7;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(34, 15);
            label8.Name = "label8";
            label8.Size = new Size(50, 20);
            label8.TabIndex = 0;
            label8.Text = "label8";
            // 
            // panel7
            // 
            panel7.BackColor = Color.White;
            panel7.Controls.Add(label7);
            panel7.Dock = DockStyle.Fill;
            panel7.ForeColor = SystemColors.ControlText;
            panel7.Location = new Point(3, 59);
            panel7.Name = "panel7";
            panel7.Size = new Size(139, 50);
            panel7.TabIndex = 6;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(34, 15);
            label7.Name = "label7";
            label7.Size = new Size(50, 20);
            label7.TabIndex = 0;
            label7.Text = "label7";
            // 
            // panel5
            // 
            panel5.BackColor = Color.DodgerBlue;
            panel5.Controls.Add(label5);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(438, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(142, 50);
            panel5.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(34, 13);
            label5.Name = "label5";
            label5.Size = new Size(74, 20);
            label5.TabIndex = 0;
            label5.Text = "Due Date";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.BackColor = Color.DodgerBlue;
            panel4.Controls.Add(label4);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(293, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(139, 50);
            panel4.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(33, 13);
            label4.Name = "label4";
            label4.Size = new Size(67, 20);
            label4.TabIndex = 0;
            label4.Text = "Amount";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.BackColor = Color.DodgerBlue;
            panel3.Controls.Add(label3);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(148, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(139, 50);
            panel3.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(43, 14);
            label3.Name = "label3";
            label3.Size = new Size(53, 20);
            label3.TabIndex = 0;
            label3.Text = "Fee ID";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DodgerBlue;
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(139, 50);
            panel2.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(28, 14);
            label2.Name = "label2";
            label2.Size = new Size(74, 20);
            label2.TabIndex = 0;
            label2.Text = "Semester";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(182, 230);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(155, 27);
            textBox1.TabIndex = 3;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(46, 228);
            label11.Name = "label11";
            label11.Size = new Size(90, 20);
            label11.TabIndex = 4;
            label11.Text = "Enter Name:";
            label11.Click += label11_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.Location = new Point(48, 262);
            label13.Name = "label13";
            label13.Size = new Size(51, 20);
            label13.TabIndex = 8;
            label13.Text = "Route:";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Bahria Town Phase 2, Korang Town, Media Town, Safari, Car Chowk", "Bahria Town Phase 1 3 4 5 6, PWD, Fire Brigade", "Highway, Soan Garden, Navel Anchorage, DHA 2", "Bahria Town Phase 7 8, DHA 1", "Askari 2, Chowk 502, Peshawar Road", "Wah Cantt, Taxila, B-17, G-15" });
            comboBox1.Location = new Point(182, 264);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(155, 28);
            comboBox1.TabIndex = 9;
            comboBox1.TabStop = false;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Cash", "Credit Card", "Bank Transfer" });
            comboBox2.Location = new Point(182, 299);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(155, 28);
            comboBox2.TabIndex = 11;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.Location = new Point(46, 298);
            label14.Name = "label14";
            label14.Size = new Size(125, 20);
            label14.TabIndex = 10;
            label14.Text = "Payment Method:";
            // 
            // printChallan
            // 
            printChallan.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            printChallan.Location = new Point(180, 342);
            printChallan.Name = "printChallan";
            printChallan.Size = new Size(120, 29);
            printChallan.TabIndex = 12;
            printChallan.Text = "Print Challan";
            printChallan.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            panel11.BackgroundImage = Properties.Resources.b47a5be5083c32e1e79254aae6ffb0af;
            panel11.BackgroundImageLayout = ImageLayout.Stretch;
            panel11.Location = new Point(16, 112);
            panel11.Name = "panel11";
            panel11.Size = new Size(76, 56);
            panel11.TabIndex = 13;
            panel11.Paint += panel11_Paint;
            // 
            // panel12
            // 
            panel12.BackgroundImage = Properties.Resources.e1df90ea2b964602e7205c8e58ad0f4a;
            panel12.BackgroundImageLayout = ImageLayout.Stretch;
            panel12.Location = new Point(110, 112);
            panel12.Name = "panel12";
            panel12.Size = new Size(76, 56);
            panel12.TabIndex = 14;
            panel12.Paint += panel12_Paint;
            // 
            // panel13
            // 
            panel13.BackgroundImage = Properties.Resources.aff803bbeef1f240f5c9458a61696773;
            panel13.BackgroundImageLayout = ImageLayout.Stretch;
            panel13.Location = new Point(16, 50);
            panel13.Name = "panel13";
            panel13.Size = new Size(76, 56);
            panel13.TabIndex = 15;
            panel13.Paint += panel13_Paint;
            // 
            // panel14
            // 
            panel14.BackgroundImage = Properties.Resources._4298feb1f7372ee2acf53a6d6a6aafab;
            panel14.BackgroundImageLayout = ImageLayout.Stretch;
            panel14.Location = new Point(110, 50);
            panel14.Name = "panel14";
            panel14.Size = new Size(76, 56);
            panel14.TabIndex = 16;
            panel14.Paint += panel14_Paint;
            // 
            // panel15
            // 
            panel15.BackColor = Color.White;
            panel15.Controls.Add(label12);
            panel15.Controls.Add(panel11);
            panel15.Controls.Add(panel12);
            panel15.Controls.Add(panel14);
            panel15.Controls.Add(panel13);
            panel15.Location = new Point(383, 204);
            panel15.Name = "panel15";
            panel15.Size = new Size(205, 174);
            panel15.TabIndex = 17;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.MidnightBlue;
            label12.Location = new Point(24, 7);
            label12.Name = "label12";
            label12.Size = new Size(159, 40);
            label12.TabIndex = 0;
            label12.Text = "Compatible Payment \r\n          Methods";
            // 
            // panel16
            // 
            panel16.BackColor = Color.MidnightBlue;
            panel16.Controls.Add(generateLabel);
            panel16.Location = new Point(1, -1);
            panel16.Name = "panel16";
            panel16.Size = new Size(603, 69);
            panel16.TabIndex = 18;
            // 
            // GenerateFee
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(604, 382);
            Controls.Add(panel16);
            Controls.Add(panel15);
            Controls.Add(printChallan);
            Controls.Add(comboBox2);
            Controls.Add(label14);
            Controls.Add(comboBox1);
            Controls.Add(label13);
            Controls.Add(label11);
            Controls.Add(textBox1);
            Controls.Add(generateLayoutPanel);
            Name = "GenerateFee";
            Text = "GenerateFee";
            Load += GenerateFee_Load;
            generateLayoutPanel.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label generateLabel;
        private TableLayoutPanel generateLayoutPanel;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private Label label4;
        private Label label3;
        private Label label2;
        private Panel panel9;
        private Label label9;
        private Panel panel8;
        private Label label8;
        private Panel panel7;
        private Label label7;
        private TextBox textBox1;
        private Label label11;
        private Label label13;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Label label14;
        private Button printChallan;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel14;
        private Panel panel15;
        private Label label12;
        private Panel panel16;
        private Panel panel10;
        private Label label10;
        private Panel panel5;
        private Label label5;
    }
}