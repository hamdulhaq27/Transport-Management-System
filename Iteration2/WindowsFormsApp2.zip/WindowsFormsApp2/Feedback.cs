﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Feedback : Form
    {
        private Button selectedButton = null; // Stores the clicked button
        private string excludeButtonName = "button2"; // Change this to the button you want to exclude

        public Feedback()
        {
            InitializeComponent();
        }

        private void Feedback_Load(object sender, EventArgs e)
        {
            foreach (Button btn in this.Controls.OfType<Button>())
            {
                if (btn.Name == excludeButtonName)
                    continue; // Skip this button

                MakeButtonCircular(btn);

                // Add event handlers
                btn.MouseEnter += Button_MouseEnter;
                btn.MouseLeave += Button_MouseLeave;
                btn.Click += Button_Click;
            }
        }

        // Method to create **perfect** circular buttons
        private void MakeButtonCircular(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Size = new Size(50, 50);
            btn.TextAlign = ContentAlignment.MiddleCenter;

            int diameter = btn.Width;
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, diameter, diameter);
            btn.Region = new Region(path);
        }

        // Hover effect (Change to Purple)
        private void Button_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.Name == excludeButtonName || btn == selectedButton)
                return; // Skip the excluded button

            btn.BackColor = Color.BlueViolet;
            btn.ForeColor = Color.White;
        }

        // Remove hover effect
        private void Button_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.Name == excludeButtonName || btn == selectedButton)
                return; // Skip the excluded button

            btn.BackColor = SystemColors.Control;
            btn.ForeColor = Color.Black;
        }

        // Click effect (Selected button stays Blue)
        private void Button_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.Name == excludeButtonName)
                return; // Skip the excluded button

            if (selectedButton != null)
            {
                selectedButton.BackColor = SystemColors.Control;
                selectedButton.ForeColor = Color.Black;
            }

            selectedButton = btn;
            selectedButton.BackColor = Color.BlueViolet;
            selectedButton.ForeColor = Color.White;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
