﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox1.UseSystemPasswordChar = false;
            }
            else
            {
                textBox1.UseSystemPasswordChar = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String password = textBox1.Text;

            if (password.Length < 4 || password.Length > 8)
            {
                MessageBox.Show("Text length must be between 4 and 8 characters!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }
    }
}
