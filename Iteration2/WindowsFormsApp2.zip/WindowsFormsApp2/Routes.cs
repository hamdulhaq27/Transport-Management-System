﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Routes : Form
    {
        public Routes()
        {
            InitializeComponent();
        }

        private void Routes_Load(object sender, EventArgs e)
        {
            // Default: Placeholder text
            LoadTimings(new List<string> { "Time" });
        }

        private void LoadTimings(List<string> timings)
        {
            comboBox2.DataSource = null;  // Reset data source
            comboBox2.Items.Clear();      // Clear previous items
            comboBox2.DataSource = timings;  // Assign new list
            comboBox2.Refresh();  // Force UI update
            comboBox2.SelectedIndex = 0;  // Select first item
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            button1.BackColor = Color.DodgerBlue;  // Selected button turns Green
            button3.BackColor = SystemColors.Control;  // Reset the other button

            LoadTimings(new List<string> { "7:00 AM", "9:30 AM" });  // Load AM timings
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            button3.BackColor = Color.DodgerBlue;  // Selected button turns Red
            button1.BackColor = SystemColors.Control;  // Reset the other button

            LoadTimings(new List<string> { "12:30 PM", "2:30 PM", "5:30 PM" });  // Load PM timings
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Status statusPage = new Status();
            statusPage.Show();
            this.Hide();
        }
    }
}
