﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace FSEPages
{
    public partial class GenerateFee : Form
    {
        public GenerateFee()
        {
            InitializeComponent();
            CenterLabel();
            StyleButton();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle= ComboBoxStyle.DropDownList;
            comboBox1.TabStop = false;
            comboBox2.TabStop = false;
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox2.FlatStyle = FlatStyle.Flat;
            generateLayoutPanel.AutoScroll = true;


            AdjustDropDownWidth(comboBox1);
            AdjustDropDownWidth(comboBox2);

            comboBox1.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox1.DrawItem += (s, e) =>
            {
                if (e.Index < 0) return;

                // Set hover and selection color
                Color backColor;
                Color textColor;

                if ((e.State & DrawItemState.Selected) != 0) // When hovered or selected
                {
                    backColor = Color.MidnightBlue; // Custom hover/selection background color
                    textColor = Color.White; // Text color for hover/selection
                }
                else
                {
                    backColor = Color.White; // Background color for normal state
                    textColor = Color.Black; // Text color for normal state
                }

                // Fill background and draw text
                e.Graphics.FillRectangle(new SolidBrush(backColor), e.Bounds);
                e.Graphics.DrawString(comboBox1.Items[e.Index].ToString(), e.Font, new SolidBrush(textColor), e.Bounds);

                e.DrawFocusRectangle(); // Keep focus rectangle visible
            };

            comboBox2.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox2.DrawItem += (s, e) =>
            {
                if (e.Index < 0) return;

                // Set hover and selection color
                Color backColor;
                Color textColor;

                if ((e.State & DrawItemState.Selected) != 0) // When hovered or selected
                {
                    backColor = Color.MidnightBlue; // Custom hover/selection background color
                    textColor = Color.White; // Text color for hover/selection
                }
                else
                {
                    backColor = Color.White; // Background color for normal state
                    textColor = Color.Black; // Text color for normal state
                }

                // Fill background and draw text
                e.Graphics.FillRectangle(new SolidBrush(backColor), e.Bounds);
                e.Graphics.DrawString(comboBox2.Items[e.Index].ToString(), e.Font, new SolidBrush(textColor), e.Bounds);

                e.DrawFocusRectangle(); // Keep focus rectangle visible
            };


        }

        private void CenterLabel()
        {

            // Center the label horizontally and vertically
            generateLabel.Left = (this.ClientSize.Width - generateLabel.Width) / 2;
        }

        private void GenerateFee_Load(object sender, EventArgs e)
        {
            CenterLabel(); // Center label on form load
        }

        private void GenerateFee_Resize(object sender, EventArgs e)
        {
            CenterLabel(); // Keep label centered on resize

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void generateLayoutPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel14_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel12_Paint(object sender, PaintEventArgs e)
        {

        }

        private void generateLabel_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void StyleButton()
        {
            Color customSlateBlue = Color.FromArgb(74, 63, 143); // Darker SlateBlue
            printChallan.BackColor = Color.DodgerBlue;
            printChallan.ForeColor = Color.White;
            printChallan.FlatStyle = FlatStyle.Flat;
            printChallan.FlatAppearance.BorderSize = 0;
            printChallan.Font = new Font("Nirmala UI", 10, FontStyle.Bold);
            printChallan.Size = new Size(140, 30); // Bigger size for better look
            printChallan.Cursor = Cursors.Hand;
            // Draw rounded corners using GraphicsPath
            printChallan.Paint += (s, e) =>
            {
                using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int radius = 20;
                    path.AddArc(1, 1, radius, radius, 180, 90);
                    path.AddArc(printChallan.Width - radius - 1, 1, radius, radius, 270, 90);
                    path.AddArc(printChallan.Width - radius - 1, printChallan.Height - radius - 1, radius, radius, 0, 90);
                    path.AddArc(1, printChallan.Height - radius - 1, radius, radius, 90, 90);
                    path.CloseFigure();

                    printChallan.Region = new Region(path);

                    e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                    // Use ControlPaint for cleaner borders
                    ControlPaint.DrawBorder(e.Graphics, printChallan.ClientRectangle,
                                            Color.DarkBlue, ButtonBorderStyle.Solid);
                }
            };

            // Hover effect
            printChallan.MouseEnter += (s, e) =>
            {
                printChallan.BackColor = Color.MidnightBlue;
            };

            printChallan.MouseLeave += (s, e) =>
            {
                printChallan.BackColor = Color.DodgerBlue;
            };

            // Click effect
            printChallan.MouseDown += (s, e) =>
            {
                printChallan.BackColor = customSlateBlue;
            };

            printChallan.MouseUp += (s, e) =>
            {
                printChallan.BackColor = Color.MidnightBlue; // Reset to hover color
            };
        }


        public void CopyDataToLayoutPanel(DataGridViewRow row)
        {
            if (row != null)
            {
                // Ensure the order of data is consistent with the panel order
                string[] rowData = new string[]
                {
            row.Cells[4].Value?.ToString(), // Serial No
            row.Cells[3].Value?.ToString(), // Semester
            row.Cells[2].Value?.ToString(), // Fee ID
            row.Cells[1].Value?.ToString(), // Amount
                };

                int i = 0;
                foreach (Control panel in generateLayoutPanel.Controls)
                {
                    if (panel is Panel innerPanel && i < rowData.Length)
                    {
                        Label label = innerPanel.Controls.OfType<Label>().FirstOrDefault();
                        if (label != null)
                        {
                            label.Text = rowData[i];
                            label.TextAlign = ContentAlignment.MiddleCenter;
                            label.AutoSize = false;
                            label.Dock = DockStyle.Fill;
                        }
                        i++;
                    }
                }
            }
        }



        private void AdjustDropDownWidth(ComboBox dropDown)
        {
            int maxWidth = 0;
            using (Graphics g = dropDown.CreateGraphics())
            {
                foreach (var item in dropDown.Items)
                {
                    int itemWidth = (int)g.MeasureString(item.ToString(), dropDown.Font).Width;
                    if (itemWidth > maxWidth)
                        maxWidth = itemWidth;
                }
            }

            dropDown.DropDownWidth = maxWidth + 25; // Add some padding
        }

    }
}
