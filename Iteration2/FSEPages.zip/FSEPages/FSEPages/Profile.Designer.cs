﻿namespace FSEPages
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            headingLabel = new Label();
            panel1 = new Panel();
            profilePic = new PictureBox();
            panel2 = new Panel();
            contactBox = new TextBox();
            textBox1 = new TextBox();
            nameBox = new TextBox();
            contactLabel = new Label();
            fullName = new Label();
            panel3 = new Panel();
            panel4 = new Panel();
            editButton = new Button();
            emailBox = new TextBox();
            emailLabel = new Label();
            label1 = new Label();
            routeBox = new ComboBox();
            genderLabel = new Label();
            genderBox = new ComboBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)profilePic).BeginInit();
            panel2.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // headingLabel
            // 
            headingLabel.AutoSize = true;
            headingLabel.Font = new Font("Nirmala UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            headingLabel.ForeColor = Color.White;
            headingLabel.Location = new Point(230, 2);
            headingLabel.Name = "headingLabel";
            headingLabel.Size = new Size(138, 50);
            headingLabel.TabIndex = 0;
            headingLabel.Text = "Profile";
            headingLabel.Click += headingLabel_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(profilePic);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(headingLabel);
            panel1.Location = new Point(-1, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(604, 228);
            panel1.TabIndex = 1;
            // 
            // profilePic
            // 
            profilePic.Image = Properties.Resources._9e837528f01cf3f42119c5aeeed1b3361;
            profilePic.Location = new Point(248, 53);
            profilePic.Name = "profilePic";
            profilePic.Size = new Size(102, 54);
            profilePic.SizeMode = PictureBoxSizeMode.StretchImage;
            profilePic.TabIndex = 1;
            profilePic.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateBlue;
            panel2.Controls.Add(contactBox);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(nameBox);
            panel2.Controls.Add(contactLabel);
            panel2.Controls.Add(fullName);
            panel2.Controls.Add(panel3);
            panel2.Location = new Point(103, 87);
            panel2.Name = "panel2";
            panel2.Size = new Size(408, 150);
            panel2.TabIndex = 2;
            panel2.Paint += panel2_Paint;
            // 
            // contactBox
            // 
            contactBox.Location = new Point(24, 104);
            contactBox.Name = "contactBox";
            contactBox.Size = new Size(316, 27);
            contactBox.TabIndex = 8;
            contactBox.Text = "12345678";
            contactBox.TextChanged += contactBox_TextChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(24, 151);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(151, 27);
            textBox1.TabIndex = 6;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // nameBox
            // 
            nameBox.Location = new Point(24, 49);
            nameBox.Name = "nameBox";
            nameBox.Size = new Size(316, 27);
            nameBox.TabIndex = 4;
            nameBox.Text = "Hamd-Ul-Haq";
            // 
            // contactLabel
            // 
            contactLabel.AutoSize = true;
            contactLabel.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            contactLabel.ForeColor = Color.White;
            contactLabel.Location = new Point(24, 82);
            contactLabel.Name = "contactLabel";
            contactLabel.Size = new Size(63, 20);
            contactLabel.TabIndex = 5;
            contactLabel.Text = "Contact";
            contactLabel.Click += label1_Click;
            // 
            // fullName
            // 
            fullName.AutoSize = true;
            fullName.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fullName.ForeColor = Color.White;
            fullName.Location = new Point(24, 23);
            fullName.Name = "fullName";
            fullName.Size = new Size(80, 20);
            fullName.TabIndex = 3;
            fullName.Text = "Full Name";
            // 
            // panel3
            // 
            panel3.Location = new Point(0, 151);
            panel3.Name = "panel3";
            panel3.Size = new Size(365, 125);
            panel3.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.BackColor = Color.DarkSlateBlue;
            panel4.Controls.Add(editButton);
            panel4.Controls.Add(emailBox);
            panel4.Controls.Add(emailLabel);
            panel4.Controls.Add(label1);
            panel4.Controls.Add(routeBox);
            panel4.Controls.Add(genderLabel);
            panel4.Controls.Add(genderBox);
            panel4.Location = new Point(102, 224);
            panel4.Name = "panel4";
            panel4.Size = new Size(408, 159);
            panel4.TabIndex = 2;
            // 
            // editButton
            // 
            editButton.Location = new Point(145, 118);
            editButton.Name = "editButton";
            editButton.Size = new Size(94, 29);
            editButton.TabIndex = 14;
            editButton.Text = "Edit Profile";
            editButton.UseVisualStyleBackColor = true;
            // 
            // emailBox
            // 
            emailBox.Location = new Point(23, 80);
            emailBox.Name = "emailBox";
            emailBox.Size = new Size(316, 27);
            emailBox.TabIndex = 13;
            emailBox.Text = "hamd123@gmail.com";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailLabel.ForeColor = Color.White;
            emailLabel.Location = new Point(24, 55);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(47, 20);
            emailLabel.TabIndex = 12;
            emailLabel.Text = "Email";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(214, 1);
            label1.Name = "label1";
            label1.Size = new Size(51, 20);
            label1.TabIndex = 11;
            label1.Text = "Route";
            // 
            // routeBox
            // 
            routeBox.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            routeBox.FormattingEnabled = true;
            routeBox.Items.AddRange(new object[] { "Bahria Town Phase 2, Korang Town, Media Town, Safari, Car Chowk", "Bahria Town Phase 1 3 4 5 6, PWD, Fire Brigade", "Highway, Soan Garden, Navel Anchorage, DHA 2", "Bahria Town Phase 7 8, DHA 1", "Askari 2, Chowk 502, Peshawar Road", "Wah Cantt, Taxila, B-17, G-15" });
            routeBox.Location = new Point(214, 24);
            routeBox.Name = "routeBox";
            routeBox.Size = new Size(125, 28);
            routeBox.TabIndex = 11;
            routeBox.TabStop = false;
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            genderLabel.ForeColor = Color.White;
            genderLabel.Location = new Point(24, 2);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new Size(60, 20);
            genderLabel.TabIndex = 10;
            genderLabel.Text = "Gender";
            // 
            // genderBox
            // 
            genderBox.FormattingEnabled = true;
            genderBox.Items.AddRange(new object[] { "Male", "Female" });
            genderBox.Location = new Point(24, 24);
            genderBox.Name = "genderBox";
            genderBox.Size = new Size(127, 28);
            genderBox.TabIndex = 9;
            genderBox.SelectedIndexChanged += genderBox_SelectedIndexChanged;
            // 
            // Profile
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(604, 382);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "Profile";
            Text = "Profile";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)profilePic).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label headingLabel;
        private Panel panel1;
        private PictureBox profilePic;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Label fullName;
        private TextBox textBox1;
        private TextBox nameBox;
        private Label contactLabel;
        private TextBox contactBox;
        private Label genderLabel;
        private ComboBox genderBox;
        private Label label1;
        private ComboBox routeBox;
        private TextBox emailBox;
        private Label emailLabel;
        private Button editButton;
    }
}