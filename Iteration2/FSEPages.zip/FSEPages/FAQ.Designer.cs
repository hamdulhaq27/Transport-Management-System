﻿namespace FSEPages
{
    partial class FAQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            transparentPanel = new Panel();
            responsePanel = new Panel();
            responseLabel = new Label();
            submitButton = new Button();
            faqDropDown = new ComboBox();
            FAQHeading = new Label();
            transparentPanel.SuspendLayout();
            responsePanel.SuspendLayout();
            SuspendLayout();
            // 
            // transparentPanel
            // 
            transparentPanel.BackColor = Color.DarkCyan;
            transparentPanel.Controls.Add(responsePanel);
            transparentPanel.Controls.Add(submitButton);
            transparentPanel.Controls.Add(faqDropDown);
            transparentPanel.Controls.Add(FAQHeading);
            transparentPanel.Location = new Point(101, 46);
            transparentPanel.Name = "transparentPanel";
            transparentPanel.Size = new Size(417, 291);
            transparentPanel.TabIndex = 0;
            transparentPanel.Paint += transparentPanel_Paint;
            // 
            // responsePanel
            // 
            responsePanel.BackColor = SystemColors.ControlText;
            responsePanel.Controls.Add(responseLabel);
            responsePanel.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            responsePanel.ForeColor = Color.White;
            responsePanel.Location = new Point(47, 138);
            responsePanel.Name = "responsePanel";
            responsePanel.Size = new Size(336, 125);
            responsePanel.TabIndex = 3;
            // 
            // responseLabel
            // 
            responseLabel.AutoSize = true;
            responseLabel.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            responseLabel.Location = new Point(3, 3);
            responseLabel.Name = "responseLabel";
            responseLabel.Size = new Size(50, 20);
            responseLabel.TabIndex = 0;
            responseLabel.Text = "label1";
            // 
            // submitButton
            // 
            submitButton.Font = new Font("Nirmala UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            submitButton.ForeColor = Color.Black;
            submitButton.Location = new Point(289, 81);
            submitButton.Name = "submitButton";
            submitButton.Size = new Size(94, 28);
            submitButton.TabIndex = 2;
            submitButton.Text = "Submit";
            submitButton.UseVisualStyleBackColor = true;
            submitButton.Click += button1_Click;
            // 
            // faqDropDown
            // 
            faqDropDown.BackColor = SystemColors.ControlText;
            faqDropDown.FlatStyle = FlatStyle.Popup;
            faqDropDown.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            faqDropDown.ForeColor = Color.White;
            faqDropDown.FormattingEnabled = true;
            faqDropDown.Items.AddRange(new object[] { "What is the bus arrival time?", "What is the bus departure time?", "What is the bus fee for this semester?", "What are payment options?", "How can I track bus?", "How can I apply for bus transporation?", "Can I change my bus route?", "Are buses available on weekends?", "Are buses available during examinations?", "Who should I contact for bus complaints?" });
            faqDropDown.Location = new Point(47, 81);
            faqDropDown.Name = "faqDropDown";
            faqDropDown.Size = new Size(243, 28);
            faqDropDown.TabIndex = 1;
            faqDropDown.Text = "Select an option ...";
            faqDropDown.SelectedIndexChanged += faqDropDown_SelectedIndexChanged;
            // 
            // FAQHeading
            // 
            FAQHeading.AutoSize = true;
            FAQHeading.BackColor = Color.Transparent;
            FAQHeading.Font = new Font("Nirmala UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FAQHeading.ForeColor = Color.White;
            FAQHeading.Location = new Point(157, 9);
            FAQHeading.Name = "FAQHeading";
            FAQHeading.Size = new Size(109, 50);
            FAQHeading.TabIndex = 0;
            FAQHeading.Text = "FAQs";
            // 
            // FAQ
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.b71411662bec784a269de9fd22741b8d;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(604, 382);
            Controls.Add(transparentPanel);
            Name = "FAQ";
            Text = "FAQ";
            transparentPanel.ResumeLayout(false);
            transparentPanel.PerformLayout();
            responsePanel.ResumeLayout(false);
            responsePanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel transparentPanel;
        private Label FAQHeading;
        private Button submitButton;
        private ComboBox faqDropDown;
        private Panel responsePanel;
        private Label responseLabel;
    }
}