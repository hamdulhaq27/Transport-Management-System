﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace FSEPages
{
    public partial class Profile : Form
    {
        public Profile()
        {
            InitializeComponent();
            CenterLabel();
            genderBox.DropDownStyle = ComboBoxStyle.DropDownList;
            routeBox.DropDownStyle = ComboBoxStyle.DropDownList;
            genderBox.TabStop = false;
            routeBox.TabStop = false;
            genderBox.FlatStyle = FlatStyle.Flat;
            routeBox.FlatStyle = FlatStyle.Flat;


            int maxWidth = 0;
            using (Graphics g = genderBox.CreateGraphics())
            {
                foreach (var item in genderBox.Items)
                {
                    int itemWidth = (int)g.MeasureString(item.ToString(), genderBox.Font).Width;
                    if (itemWidth > maxWidth)
                        maxWidth = itemWidth;
                }
            }

            genderBox.DropDownWidth = maxWidth + 25; // Add some padding


            maxWidth = 0;
            using (Graphics g = routeBox.CreateGraphics())
            {
                foreach (var item in routeBox.Items)
                {
                    int itemWidth = (int)g.MeasureString(item.ToString(), routeBox.Font).Width;
                    if (itemWidth > maxWidth)
                        maxWidth = itemWidth;
                }
            }

            routeBox.DropDownWidth = maxWidth + 25; // Add some padding

            genderBox.DrawMode = DrawMode.OwnerDrawFixed;
            genderBox.DropDownStyle = ComboBoxStyle.DropDownList;

            genderBox.DrawItem += (s, e) =>
            {
                if (e.Index < 0) return;

                // Set hover and selection color
                Color backColor;
                Color textColor;

                if ((e.State & DrawItemState.Selected) != 0) // When hovered or selected
                {
                    backColor = Color.MidnightBlue; // Custom hover/selection background color
                    textColor = Color.White; // Text color for hover/selection
                }
                else
                {
                    backColor = Color.White; // Background color for normal state
                    textColor = Color.Black; // Text color for normal state
                }

                // Fill background and draw text
                e.Graphics.FillRectangle(new SolidBrush(backColor), e.Bounds);
                e.Graphics.DrawString(genderBox.Items[e.Index].ToString(), e.Font, new SolidBrush(textColor), e.Bounds);

                e.DrawFocusRectangle(); // Keep focus rectangle visible
            };

            routeBox.DrawMode = DrawMode.OwnerDrawFixed;
            routeBox.DropDownStyle = ComboBoxStyle.DropDownList;

            routeBox.DrawItem += (s, e) =>
            {
                if (e.Index < 0) return;

                // Set hover and selection color
                Color backColor;
                Color textColor;

                if ((e.State & DrawItemState.Selected) != 0) // When hovered or selected
                {
                    backColor = Color.MidnightBlue; // Custom hover/selection background color
                    textColor = Color.White; // Text color for hover/selection
                }
                else
                {
                    backColor = Color.White; // Background color for normal state
                    textColor = Color.Black; // Text color for normal state
                }

                // Fill background and draw text
                e.Graphics.FillRectangle(new SolidBrush(backColor), e.Bounds);
                e.Graphics.DrawString(routeBox.Items[e.Index].ToString(), e.Font, new SolidBrush(textColor), e.Bounds);

                e.DrawFocusRectangle(); // Keep focus rectangle visible
            };
            editButton.Left = 120;

            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, profilePic.Width, profilePic.Height);
            profilePic.Region = new Region(path);

            StyleButton(); // Apply styling to existing button
        }

        private void headingLabel_Click(object sender, EventArgs e)
        {

        }

        private void CenterLabel()
        {

            // Center the label horizontally and vertically
            headingLabel.Left = (this.ClientSize.Width - headingLabel.Width) / 2;
        }

        private void StyleButton()
        {
            Color customSlateBlue = Color.FromArgb(74, 63, 143); // Darker SlateBlue
            editButton.BackColor = Color.DodgerBlue;
            editButton.ForeColor = Color.White;
            editButton.FlatStyle = FlatStyle.Flat;
            editButton.FlatAppearance.BorderSize = 0;
            editButton.Font = new Font("Nirmala UI", 10, FontStyle.Bold);
            editButton.Size = new Size(150, 30); // Bigger size for better look
            editButton.Cursor = Cursors.Hand;
            // Draw rounded corners using GraphicsPath

            editButton.Paint += (s, e) =>
            {
                using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int radius = 20;
                    path.AddArc(1, 1, radius, radius, 180, 90);
                    path.AddArc(editButton.Width - radius - 1, 1, radius, radius, 270, 90);
                    path.AddArc(editButton.Width - radius - 1, editButton.Height - radius - 1, radius, radius, 0, 90);
                    path.AddArc(1, editButton.Height - radius - 1, radius, radius, 90, 90);
                    path.CloseFigure();

                    editButton.Region = new Region(path);

                    e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                    // Use ControlPaint for cleaner borders
                    ControlPaint.DrawBorder(e.Graphics, editButton.ClientRectangle,
                                            Color.DarkBlue, ButtonBorderStyle.Solid);
                }
            };

            // Hover effect
            editButton.MouseEnter += (s, e) =>
            {
                editButton.BackColor = Color.MidnightBlue;
            };

            editButton.MouseLeave += (s, e) =>
            {
                editButton.BackColor = Color.DodgerBlue;
            };

            // Click effect
            editButton.MouseDown += (s, e) =>
            {
                editButton.BackColor = customSlateBlue;
            };

            editButton.MouseUp += (s, e) =>
            {
                editButton.BackColor = Color.MidnightBlue; // Reset to hover color
            };
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void genderBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void contactBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
